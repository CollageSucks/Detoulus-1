﻿﻿﻿﻿﻿﻿﻿﻿﻿﻿ ﻿﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using Newtonsoft.Json;
using System.Threading.Tasks;

namespace UpdatedRevitBuildingCreator
{
    public class LlmIntegration
    {
        private const string ApiUrl = "https://api.openai.com/v1/chat/completions"; // OpenAI API endpoint
        private const string ApiKey = Environment.GetEnvironmentVariable("OPENAI_API_KEY"); // Use environment variable for API Key

public async Task<string> CallModel(object inputData)
{
Console.WriteLine($"Calling model with input data: {JsonConvert.SerializeObject(inputData)}");
        {
            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", ApiKey);
                var response = await client.PostAsJsonAsync(ApiUrl, inputData);
                response.EnsureSuccessStatusCode();
                return await response.Content.ReadAsStringAsync();
            }
        }

        public async Task<string> CallModel(string modelName, object inputData)
        {
            if (modelName == "gpt-4o-minni")
            {
                throw new UnauthorizedAccessException("Access to the gpt-4o-minni model is restricted.");
            }

            // Additional logic for calling different models can be added here
            return await CallModel(inputData);
        }
    }
}
