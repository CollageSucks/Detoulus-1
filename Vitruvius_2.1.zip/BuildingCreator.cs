﻿﻿﻿﻿﻿﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace UpdatedRevitBuildingCreator
{
    public class CreateBuilding : IExternalCommand
    {
        private readonly Document _doc;
        private readonly LlmIntegration _llmIntegration;

        public CreateBuilding(Document document)
        {
            _doc = document;
            _llmIntegration = new LlmIntegration();
        }

        public Result Execute(ExternalCommandData commandData, ElementSet elements)
        {
            _doc = commandData.Application.ActiveUIDocument.Document;
            // Call GenerateBuildingFromCommand directly
            GenerateBuildingFromCommand("Your command here").Wait();
            return Result.Succeeded;
        }

        public async Task GenerateBuildingFromCommand(string userCommand)
        {
            await CreateFloors(3); // Example: Create 3 floors
            {
                try
                {
                    string llmResponse = await _llmIntegration.ProcessCommandAsync(userCommand);
                    Dictionary<string, string> parsedData = _llmIntegration.ParseResponse(llmResponse);

                    using (Transaction transaction = new Transaction(_doc, "Generate Building"))
                    {
                        try
                        {
                            transaction.Start();

                            if (parsedData.ContainsKey("wall"))
                            {
                                CreateWall();
                            }

                            if (parsedData.ContainsKey("room"))
                            {
                                CreateRoom();
                            }

                            if (parsedData.ContainsKey("window"))
                            {
                                CreateWindow();
                            }

                            if (parsedData.ContainsKey("door"))
                            {
                                CreateDoor();
                            }

                            transaction.Commit();  
                        }
                    }
                }
                catch (Exception ex)
                {
                    TaskDialog.Show("Error", ex.Message);
                }
            }
        }

        private async Task CreateFloors(int numberOfFloors)
        {
            for (int i = 0; i < numberOfFloors; i++)
            {
                Level newLevel = Level.Create(_doc, i * 10); // Assuming each floor is 10 units high
                newLevel.Name = $"Level {i + 1}";
            }
        }

        private void CreateWall()        
        private void CreateWindow()
        {
            FamilySymbol windowSymbol = new FilteredElementCollector(_doc)
                .OfClass(typeof(FamilySymbol))
                .OfCategory(BuiltInCategory.OST_Windows)
                .FirstOrDefault() as FamilySymbol;

            if (windowSymbol == null || !windowSymbol.IsActive)
            {
                TaskDialog.Show("Error", "Required Window family not found or not active.");
                return;
            }

            // Define the location for the window
            XYZ windowLocation = new XYZ(5, 0, 5); // Example location
            _doc.Create.NewFamilyInstance(windowLocation, windowSymbol, StructuralType.NonStructural);
        }

        private void CreateDoor()
        {
            FamilySymbol doorSymbol = new FilteredElementCollector(_doc)
                .OfClass(typeof(FamilySymbol))
                .OfCategory(BuiltInCategory.OST_Doors)
                .FirstOrDefault() as FamilySymbol;

            if (doorSymbol == null || !doorSymbol.IsActive)
            {
                TaskDialog.Show("Error", "Required Door family not found or not active.");
                return;
            }

            // Define the location for the door
            XYZ doorLocation = new XYZ(0, 0, 0); // Example location
            _doc.Create.NewFamilyInstance(doorLocation, doorSymbol, StructuralType.NonStructural);
        }

        private void CreateStaircaseBetweenFloors(Level lowerLevel, Level upperLevel)
        {
            // Logic to create a staircase between the two levels
            // Assuming a staircase type is available in the document
            StairsType stairsType = new FilteredElementCollector(_doc)
                .OfClass(typeof(StairsType))
                .FirstOrDefault() as StairsType;

            if (stairsType == null)
            {
                TaskDialog.Show("Error", "Required StairsType not found in the document.");
                return;
            }

            // Define the location for the staircase
            XYZ basePoint = new XYZ(0, 0, lowerLevel.Elevation);
            XYZ topPoint = new XYZ(0, 0, upperLevel.Elevation);

            // Create the staircase
            Stairs.Create(_doc, stairsType.Id, basePoint, topPoint, lowerLevel.Id, upperLevel.Id);
        }

        private void CreateStarsBetweenFloors(Level lowerLevel, Level upperLevel)
        {
            // Logic to create stars between the two levels
            // This could involve placing a family instance or a custom element
        }

        private void CreateStarsBetweenFloors(Level lowerLevel, Level upperLevel)
        {
            // Logic to create stars between the two levels
            // This could involve placing a family instance or a custom element
            XYZ starLocation = new XYZ(5, 5, (lowerLevel.Elevation + upperLevel.Elevation) / 2);
            // Assuming a star family is loaded in the document
            FamilySymbol starSymbol = new FilteredElementCollector(_doc)
                .OfClass(typeof(FamilySymbol))
                .FirstOrDefault() as FamilySymbol;

            if (starSymbol != null && starSymbol.IsActive == false)
            {
                starSymbol.Activate();
            }

            if (starSymbol != null)
            {
                _doc.Create.NewFamilyInstance(starLocation, starSymbol, lowerLevel.Id, StructuralType.NonStructural);
            }
        }

        private void CreateRoom()
    }
}
