﻿﻿using System;
using System.Windows.Forms;
using Autodesk.Revit.DB;

namespace UpdatedRevitBuildingCreator
{
    public class BuildingInputForm : Form
    {
        private readonly CreateBuilding _createBuilding;
        private TextBox inputBox;
        private Button sendButton;

        public BuildingInputForm(CreateBuilding createBuilding)
        {
            _createBuilding = createBuilding;
            InitializeComponents();
        }

        private void InitializeComponents()
        {
            this.Text = "Building Creator Input";

            inputBox = new TextBox { Dock = DockStyle.Top };
            sendButton = new Button { Text = "Generate Building", Dock = DockStyle.Top };

            sendButton.Click += async (sender, args) =>
            {
                string command = inputBox.Text.Trim();
                if (string.IsNullOrEmpty(command))
                {
                    MessageBox.Show("Please enter a command.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                try
                {
                    await _createBuilding.GenerateBuildingFromCommand(command);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            };

            this.Controls.Add(inputBox);
            this.Controls.Add(sendButton);
        }
    }
}
