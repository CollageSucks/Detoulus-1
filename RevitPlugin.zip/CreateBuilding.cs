using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace UpdatedRevitBuildingCreator
{
    public class CreateBuilding : IExternalCommand
    {
        private Document _doc; 
        private readonly LlmIntegration _llmIntegration;

        // Constructor removed; _doc will be initialized in Execute method

        public Result Execute(ExternalCommandData commandData, ElementSet elements)
        {
            _doc = commandData.Application.ActiveUIDocument.Document;
            GenerateBuildingFromCommand("Your command here").GetAwaiter().GetResult(); 
            return Result.Succeeded;
        }

        public async Task GenerateBuildingFromCommand(string userCommand)
        {
            await CreateFloors(3); 
            try
            {
                string llmResponse = await _llmIntegration.ProcessCommandAsync(userCommand);
                Dictionary<string, string> parsedData = _llmIntegration.ParseResponse(llmResponse);

                using (Transaction transaction = new Transaction(_doc, "Generate Building"))
                {
                    try
                    {
                        transaction.Start();

                        if (parsedData.ContainsKey("wall"))
                        {
                            CreateWall();
                        }

                        if (parsedData.ContainsKey("room"))
                        {
                            CreateRoom();
                        }

                        if (parsedData.ContainsKey("window"))
                        {
                            CreateWindow();
                        }

                        if (parsedData.ContainsKey("door"))
                        {
                            CreateDoor();
                        }

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.RollBack();
                        TaskDialog.Show("Error", ex.Message);
                    }
                }
            }
            catch (Exception ex)
            {
                TaskDialog.Show("Error", ex.Message);
            }
        }

        private async Task CreateFloors(int numberOfFloors)
        {
            for (int i = 0; i < numberOfFloors; i++)
            {
                Level newLevel = Level.Create(_doc, i * 10); 
                newLevel.Name = $"Level {i + 1}";
            }
        }

        private void CreateWall()
        {
            WallType wallType = new FilteredElementCollector(_doc)
                .OfClass(typeof(WallType))
                .FirstOrDefault() as WallType;

            if (wallType == null)
            {
                TaskDialog.Show("Error", "No wall type found in the document.");
                return;
            }

            XYZ startPoint = new XYZ(0, 0, 0); 
            XYZ endPoint = new XYZ(10, 0, 0); 
            Line wallLine = Line.CreateBound(startPoint, endPoint);

            Wall.Create(_doc, wallLine, wallType.Id, false);
            TaskDialog.Show("CreateWall", "Wall created successfully.");
        }

        private void CreateWindow()
        {
            FamilySymbol windowSymbol = new FilteredElementCollector(_doc)
                .OfClass(typeof(FamilySymbol))
                .OfCategory(BuiltInCategory.OST_Windows)
                .FirstOrDefault() as FamilySymbol;

            if (windowSymbol == null || !windowSymbol.IsActive)
            {
                TaskDialog.Show("Error", "Required Window family not found or not active.");
                return;
            }

            XYZ windowLocation = new XYZ(5, 0, 5); 
            Wall wall = new FilteredElementCollector(_doc)
                .OfClass(typeof(Wall))
                .FirstOrDefault() as Wall;

            if (wall == null)
            {
                TaskDialog.Show("Error", "No wall found to place the window.");
                return;
            }

            _doc.Create.NewFamilyInstance(windowLocation, windowSymbol, wall, StructuralType.NonBearing);
            TaskDialog.Show("CreateWindow", "Window created successfully.");
        }

        private void CreateDoor()
        {
            FamilySymbol doorSymbol = new FilteredElementCollector(_doc)
                .OfClass(typeof(FamilySymbol))
                .OfCategory(BuiltInCategory.OST_Doors)
                .FirstOrDefault() as FamilySymbol;

            if (doorSymbol == null || !doorSymbol.IsActive)
            {
                TaskDialog.Show("Error", "Required Door family not found or not active.");
                return;
            }

            XYZ doorLocation = new XYZ(0, 0, 0); 
            Wall wall = new FilteredElementCollector(_doc)
                .OfClass(typeof(Wall))
                .FirstOrDefault() as Wall;

            if (wall == null)
            {
                TaskDialog.Show("Error", "No wall found to place the door.");
                return;
            }

            _doc.Create.NewFamilyInstance(doorLocation, doorSymbol, wall, StructuralType.NonBearing);
            TaskDialog.Show("CreateDoor", "Door created successfully.");
        }

        private void CreateRoom()
        {
            IList<Wall> walls = new FilteredElementCollector(_doc)
                .OfClass(typeof(Wall))
                .ToElements()
                .Cast<Wall>()
                .ToList();

            if (walls.Count < 4)
            {
                TaskDialog.Show("Error", "Not enough walls to create a room.");
                return;
            }

            using (Transaction transaction = new Transaction(_doc, "Create Room"))
            {
                transaction.Start();

                BoundingBoxXYZ boundingBox = walls[0].get_BoundingBox(null);
                XYZ minPoint = boundingBox.Min;
                XYZ maxPoint = boundingBox.Max;

                Room newRoom = Room.Create(_doc, walls[0].LevelId);
                newRoom.Location.Move(new XYZ((maxPoint.X + minPoint.X) / 2, (maxPoint.Y + minPoint.Y) / 2, 0));

                transaction.Commit();
                TaskDialog.Show("CreateRoom", "Room created successfully.");
            }
        }
    }
}
