using System;
using Autodesk.Revit.DB;

namespace RevitPlugin
{
    public class CreateBuilding
    {
        private readonly Document _doc;

        public CreateBuilding(Document doc = null)
        {
            _doc = doc;
        }

        public void GenerateBuildingFromCommand(string command)
        {
            if (string.IsNullOrWhiteSpace(command))
            {
                throw new ArgumentException("Command cannot be empty", nameof(command));
            }

            var elementTypes = new ElementTypes(_doc);
            elementTypes.EnsureSymbolsAreActive();

            // Example positions for doors and windows
            XYZ doorLocation = new XYZ(0, 0, 0); // Adjust as needed
            XYZ windowLocation = new XYZ(5, 0, 3); // Adjust as needed

            // Create a door
            FamilySymbol doorType = elementTypes.GetDoorType();
            if (doorType != null)
            {
                using (Transaction trans = new Transaction(_doc, "Place Door"))
                {
                    trans.Start();
                    _doc.Create.NewFamilyInstance(doorLocation, doorType, Autodesk.Revit.DB.Structure.StructuralType.NonStructural);
                    trans.Commit();
                }
            }

            // Create a window
            FamilySymbol windowType = elementTypes.GetWindowType();
            if (windowType != null)
            {
                using (Transaction trans = new Transaction(_doc, "Place Window"))
                {
                    trans.Start();
                    _doc.Create.NewFamilyInstance(windowLocation, windowType, Autodesk.Revit.DB.Structure.StructuralType.NonStructural);
                    trans.Commit();
                }
            }
        }
    }
}
