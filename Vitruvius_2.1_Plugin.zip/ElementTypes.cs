using Autodesk.Revit.DB;
using System.Linq;

namespace RevitPlugin
{
    public class ElementTypes
    {
        private readonly Document _doc;

        public ElementTypes(Document doc)
        {
            _doc = doc;
        }

        public void EnsureSymbolsAreActive()
        {
            var doorType = GetDoorType();
            if (doorType != null && !doorType.IsActive)
            {
                doorType.Activate();
            }

            var windowType = GetWindowType();
            if (windowType != null && !windowType.IsActive)
            {
                windowType.Activate();
            }
        }

        public FamilySymbol GetDoorType()
        {
            // Get the first door type in the project
            FilteredElementCollector collector = new FilteredElementCollector(_doc);
            return collector
                .OfClass(typeof(FamilySymbol))
                .OfCategory(BuiltInCategory.OST_Doors)
                .Cast<FamilySymbol>()
                .FirstOrDefault();
        }

        public FamilySymbol GetWindowType()
        {
            // Get the first window type in the project
            FilteredElementCollector collector = new FilteredElementCollector(_doc);
            return collector
                .OfClass(typeof(FamilySymbol))
                .OfCategory(BuiltInCategory.OST_Windows)
                .Cast<FamilySymbol>()
                .FirstOrDefault();
        }
    }
}
