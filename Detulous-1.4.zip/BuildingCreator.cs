using System;
using System.Threading.Tasks;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.Attributes;

namespace RevitPlugin
{
    [Transaction(TransactionMode.Manual)]
    public class BuildingCreatorCommand : IExternalCommand
    {
        private Document _doc;
        private readonly LlmIntegration _llmIntegration;

        public BuildingCreatorCommand()
        {
            _llmIntegration = new LlmIntegration();
        }

        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            try
            {
                _doc = commandData.Application.ActiveUIDocument.Document;
                
                using (var form = new BuildingInputForm(_doc))
                {
                    form.ShowDialog();
                }
                
                return Result.Succeeded;
            }
            catch (Exception ex)
            {
                message = ex.Message;
                return Result.Failed;
            }
        }
    }
}
