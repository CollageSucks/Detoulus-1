# Detulous 1.3 - Revit Plugin

This plugin allows for automated building creation in Revit using natural language commands.

## Installation

1. Copy the contents of this folder to: `%APPDATA%\Autodesk\Revit\Addins\2024\`
2. Restart Revit if it's already running

## Files Included
- RevitBuildingCreator.dll - The main plugin assembly
- BuildingCreator.addin - The Revit add-in manifest file

## Requirements
- Autodesk Revit 2024
- .NET Framework 4.8

## Usage
1. Open Revit
2. Look for "Building Creator" in the Add-Ins tab
3. Click to open the Building Creator dialog
4. Enter your building description
5. Click "Generate Building" to create the building

## Support
For support, please contact the development team.
