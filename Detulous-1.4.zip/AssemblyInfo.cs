using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Detulous Building Creator")]
[assembly: AssemblyDescription("Revit plugin for automated building creation")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Detulous")]
[assembly: AssemblyProduct("Detulous Building Creator")]
[assembly: AssemblyCopyright("Copyright © 2024")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("12345678-1234-1234-1234-123456789012")]
[assembly: AssemblyVersion("1.3.0.0")]
[assembly: AssemblyFileVersion("1.3.0.0")]
