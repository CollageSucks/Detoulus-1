using System;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace RevitPlugin
{
    public class BuildingParameters
    {
        public double Width { get; set; }
        public double Length { get; set; }
        public double Height { get; set; }
    }

    public class LlmIntegration
    {
        private readonly HttpClient _httpClient;
        private const string API_KEY = "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"; // Replace with actual API key
        private const string API_ENDPOINT = "https://api.openai.com/v1/chat/completions";

        public LlmIntegration()
        {
            _httpClient = new HttpClient();
            _httpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {API_KEY}");
        }

        public async Task<BuildingParameters> GetBuildingParametersAsync(string command)
        {
            var requestBody = new
            {
                model = "gpt-4",
                messages = new[]
                {
                    new
                    {
                        role = "system",
                        content = "You are a building parameter extractor. Extract width, length, and height in feet from the user's description. Respond only with JSON in the format: {\"width\": X, \"length\": Y, \"height\": Z}"
                    },
                    new
                    {
                        role = "user",
                        content = command
                    }
                }
            };

            var response = await _httpClient.PostAsync(
                API_ENDPOINT,
                new StringContent(JsonSerializer.Serialize(requestBody), Encoding.UTF8, "application/json")
            );

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception($"Failed to get response from LLM: {response.StatusCode}");
            }

            var responseContent = await response.Content.ReadAsStringAsync();
            var jsonResponse = JsonSerializer.Deserialize<JsonElement>(responseContent);
            var content = jsonResponse.GetProperty("choices")[0].GetProperty("message").GetProperty("content").GetString();
            
            return JsonSerializer.Deserialize<BuildingParameters>(content);
        }
    }
}
