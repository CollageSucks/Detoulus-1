using System.Threading.Tasks;
using System;
using Autodesk.Revit.DB;

namespace RevitPlugin
{
    public class CreateBuilding
    {
        private readonly Document _doc;
        private readonly LlmIntegration _llmIntegration;

        public CreateBuilding(Document doc)
        {
            _doc = doc ?? throw new ArgumentNullException(nameof(doc));
            _llmIntegration = new LlmIntegration();
        }

        public async Task GenerateBuildingFromCommand(string command)
        {
            if (string.IsNullOrWhiteSpace(command))
            {
                throw new ArgumentException("Command cannot be empty", nameof(command));
            }

            // Get building parameters from LLM
            var buildingParams = await _llmIntegration.GetBuildingParametersAsync(command);

            using (Transaction trans = new Transaction(_doc, "Generate Building"))
            {
                trans.Start();
                try
                {
                    // Create levels
                    Level level0 = Level.Create(_doc, 0);
                    Level level1 = Level.Create(_doc, buildingParams.Height);

                    // Create floor plan
                    XYZ point1 = XYZ.Zero;
                    XYZ point2 = new XYZ(buildingParams.Width, 0, 0);
                    XYZ point3 = new XYZ(buildingParams.Width, buildingParams.Length, 0);
                    XYZ point4 = new XYZ(0, buildingParams.Length, 0);

                    CurveArray profile = new CurveArray();
                    profile.Append(Line.CreateBound(point1, point2));
                    profile.Append(Line.CreateBound(point2, point3));
                    profile.Append(Line.CreateBound(point3, point4));
                    profile.Append(Line.CreateBound(point4, point1));

                    // Create walls
                    foreach (Curve curve in profile)
                    {
                        Wall.Create(_doc, curve, level0.Id, true);
                    }

                    trans.Commit();
                }
                catch (Exception ex)
                {
                    trans.RollBack();
                    throw new Exception("Failed to generate building: " + ex.Message, ex);
                }
            }
        }
    }
}
