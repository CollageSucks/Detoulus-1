using System;
using System.Threading.Tasks;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.Attributes;
using System.Windows.Forms;

namespace RevitPlugin
{
    [Transaction(TransactionMode.Manual)]
    [Regeneration(RegenerationOption.Manual)]
    public class BuildingCreatorCommand : IExternalCommand
    {
        private Document _doc;
        private readonly LlmIntegration _llmIntegration;
        private string _userCommand;

        public BuildingCreatorCommand()
        {
            _llmIntegration = new LlmIntegration();
        }

        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            try
            {
                UIApplication uiapp = commandData.Application;
                UIDocument uidoc = uiapp.ActiveUIDocument;
                _doc = uidoc.Document;

                if (_doc == null)
                {
                    message = "No active document found.";
                    return Result.Failed;
                }

                // Show form to get user input
                using (var form = new BuildingInputForm())
                {
                    if (form.ShowDialog() != DialogResult.OK)
                    {
                        return Result.Cancelled;
                    }
                    _userCommand = form.Command;
                }

                // Create the building within a transaction
                using (Transaction trans = new Transaction(_doc, "Create Building"))
                {
                    trans.Start();
                    var createBuilding = new CreateBuilding(_doc);
                    createBuilding.GenerateBuildingFromCommand(_userCommand).Wait();
                    trans.Commit();
                }

                TaskDialog.Show("Success", "Building has been created successfully!");
                return Result.Succeeded;
            }
            catch (Exception ex)
            {
                message = ex.Message;
                TaskDialog.Show("Error", $"Failed to create building: {ex.Message}");
                return Result.Failed;
            }
        }
    }
}
