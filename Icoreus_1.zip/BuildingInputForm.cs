﻿using System;
using System.Windows.Forms; // Use System.Windows.Forms for the form
using Form = System.Windows.Forms.Form; // Alias to avoid ambiguity
using Autodesk.Revit.DB;

namespace RevitPlugin
{
    public class BuildingInputForm : Form
    {
        private readonly CreateBuilding _createBuilding;
        private TextBox inputBox;
        private Button sendButton;

        public BuildingInputForm(Document doc)
        {
            _createBuilding = new CreateBuilding(doc);
            InitializeComponents();
        }

        private void InitializeComponents()
        {
            this.Text = "Building Creator Input";
            this.Width = 400;
            this.Height = 200;

            inputBox = new TextBox 
            { 
                Dock = DockStyle.Top,
                Multiline = true,
                Height = 100
            };

            sendButton = new Button 
            { 
                Text = "Generate Building", 
                Dock = DockStyle.Top,
                Height = 30
            };

            sendButton.Click += async (sender, args) =>
            {
                string command = inputBox.Text.Trim();
                if (string.IsNullOrEmpty(command))
                {
                    MessageBox.Show("Please enter a command.", "Input Error", 
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                sendButton.Enabled = false;
                inputBox.Enabled = false;

                try
                {
                    await _createBuilding.GenerateBuildingFromCommand(command);
                    MessageBox.Show("Building generation completed!", "Success", 
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}", "Error", 
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    sendButton.Enabled = true;
                    inputBox.Enabled = true;
                }
            };

            this.Controls.Add(sendButton);
            this.Controls.Add(inputBox);
        }
    }
}
