using System;
using Autodesk.Revit.DB;
using System.Collections.Generic;

namespace RevitPlugin
{
    public class CreateBuilding
    {
        private readonly Document _doc;

        public CreateBuilding(Document doc = null)
        {
            _doc = doc;
        }

        public void GenerateBuildingFromCommand(string command)
        {
            if (string.IsNullOrWhiteSpace(command))
            {
                throw new ArgumentException("Command cannot be empty", nameof(command));
            }

            var elementTypes = new ElementTypes(_doc);
            elementTypes.EnsureSymbolsAreActive();

            // Delete any existing walls, doors, and windows first
            using (Transaction cleanupTrans = new Transaction(_doc, "Cleanup Existing Elements"))
            {
                cleanupTrans.Start();
                try
                {
                    // Find and delete existing walls
                    var existingWalls = new FilteredElementCollector(_doc)
                        .OfClass(typeof(Wall))
                        .ToElements();
                    foreach (Element wall in existingWalls)
                    {
                        _doc.Delete(wall.Id);
                    }

                    // Find and delete existing doors and windows
                    var existingFamilyInstances = new FilteredElementCollector(_doc)
                        .OfClass(typeof(FamilyInstance))
                        .ToElements();
                    foreach (Element element in existingFamilyInstances)
                    {
                        FamilyInstance instance = element as FamilyInstance;
                        if (instance?.Category != null && 
                            (instance.Category.Id.IntegerValue == (int)BuiltInCategory.OST_Doors ||
                             instance.Category.Id.IntegerValue == (int)BuiltInCategory.OST_Windows))
                        {
                            _doc.Delete(instance.Id);
                        }
                    }

                    cleanupTrans.Commit();
                }
                catch (Exception ex)
                {
                    cleanupTrans.RollBack();
                    throw new Exception($"Error cleaning up existing elements: {ex.Message}");
                }
            }

            // Create walls first
            Level level = new FilteredElementCollector(_doc)
                .OfClass(typeof(Level))
                .FirstElement() as Level;

            if (level == null)
            {
                using (Transaction trans = new Transaction(_doc, "Create Level"))
                {
                    trans.Start();
                    level = Level.Create(_doc, 0);
                    trans.Commit();
                }
            }

            // Create a rectangular room with four walls
            double roomWidth = 20;
            double roomDepth = 15;
            double wallHeight = 10;
            double windowHeight = 3; // Window height from floor

            // Define wall lines counter-clockwise to ensure correct orientation
            XYZ p1 = XYZ.Zero;
            XYZ p2 = new XYZ(roomWidth, 0, 0);
            XYZ p3 = new XYZ(roomWidth, roomDepth, 0);
            XYZ p4 = new XYZ(0, roomDepth, 0);

            List<Wall> walls = new List<Wall>();
            WallType wallType = new FilteredElementCollector(_doc)
                .OfClass(typeof(WallType))
                .FirstElement() as WallType;

            if (wallType == null)
            {
                throw new Exception("No wall type found in the project.");
            }
            
            using (Transaction trans = new Transaction(_doc, "Create Walls"))
            {
                trans.Start();

                try
                {
                    // Create walls counter-clockwise for correct orientation
                    Line[] lines = new Line[]
                    {
                        Line.CreateBound(p1, p4), // Start with back wall
                        Line.CreateBound(p4, p3), // Left wall
                        Line.CreateBound(p3, p2), // Front wall
                        Line.CreateBound(p2, p1)  // Right wall
                    };

                    foreach (Line line in lines)
                    {
                        // Create wall with exterior face on the correct side
                        Wall wall = Wall.Create(_doc, line, wallType.Id, level.Id, wallHeight, 0, false, false);
                        
                        // Set the wall's location line to Core Exterior
                        try
                        {
                            Parameter locationParam = wall.get_Parameter(BuiltInParameter.WALL_KEY_REF_PARAM);
                            if (locationParam != null)
                            {
                                locationParam.Set(1); // 1 = Exterior
                            }
                        }
                        catch
                        {
                            // If setting location line fails, continue
                        }

                        walls.Add(wall);
                    }

                    // Join walls at corners
                    for (int i = 0; i < walls.Count; i++)
                    {
                        int nextIndex = (i + 1) % walls.Count;
                        try
                        {
                            JoinGeometryUtils.JoinGeometry(_doc, walls[i], walls[nextIndex]);
                        }
                        catch
                        {
                            // If joining fails, continue without joining
                        }
                    }

                    trans.Commit();
                }
                catch (Exception ex)
                {
                    trans.RollBack();
                    throw new Exception($"Error creating walls: {ex.Message}");
                }
            }

            // Create doors and windows on the walls
            FamilySymbol doorType = elementTypes.GetDoorType();
            FamilySymbol windowType = elementTypes.GetWindowType();

            if (doorType != null && windowType != null && walls.Count == 4)
            {
                using (Transaction trans = new Transaction(_doc, "Place Doors and Windows"))
                {
                    trans.Start();

                    try
                    {
                        // Place a door in the middle of the front wall
                        Wall frontWall = walls[2]; // Front wall is now index 2 in counter-clockwise order
                        var frontCurve = frontWall.Location as LocationCurve;
                        if (frontCurve != null)
                        {
                            XYZ wallStart = frontCurve.Curve.GetEndPoint(0);
                            XYZ wallEnd = frontCurve.Curve.GetEndPoint(1);
                            XYZ doorLocation = (wallStart + wallEnd) / 2; // Middle of wall

                            // Create door facing exterior
                            FamilyInstance door = _doc.Create.NewFamilyInstance(
                                doorLocation,
                                doorType,
                                frontWall,
                                level,
                                Autodesk.Revit.DB.Structure.StructuralType.NonStructural);

                            // Flip door if needed to face exterior
                            if (door.FacingFlipped)
                            {
                                door.flipFacing();
                            }
                            if (door.HandFlipped)
                            {
                                door.flipHand();
                            }
                        }

                        // Place windows on the side walls
                        foreach (Wall wall in new[] { walls[1], walls[3] }) // Side walls are now indices 1 and 3
                        {
                            var sideCurve = wall.Location as LocationCurve;
                            if (sideCurve != null)
                            {
                                XYZ wallStart = sideCurve.Curve.GetEndPoint(0);
                                XYZ wallEnd = sideCurve.Curve.GetEndPoint(1);
                                XYZ wallDir = (wallEnd - wallStart).Normalize();
                                double wallLength = wallStart.DistanceTo(wallEnd);

                                // Place two windows at 1/3 and 2/3 of the wall length
                                for (int i = 1; i <= 2; i++)
                                {
                                    double offset = wallLength * i / 3;
                                    XYZ windowLocation = wallStart + wallDir * offset;
                                    // Add window height
                                    windowLocation = new XYZ(windowLocation.X, windowLocation.Y, windowLocation.Z + windowHeight);

                                    // Create window facing exterior
                                    FamilyInstance window = _doc.Create.NewFamilyInstance(
                                        windowLocation,
                                        windowType,
                                        wall,
                                        level,
                                        Autodesk.Revit.DB.Structure.StructuralType.NonStructural);

                                    // Flip window if needed to face exterior
                                    if (window.FacingFlipped)
                                    {
                                        window.flipFacing();
                                    }
                                    if (window.HandFlipped)
                                    {
                                        window.flipHand();
                                    }
                                }
                            }
                        }

                        trans.Commit();
                    }
                    catch (Exception ex)
                    {
                        trans.RollBack();
                        throw new Exception($"Error placing doors and windows: {ex.Message}");
                    }
                }
            }
        }
    }
}
